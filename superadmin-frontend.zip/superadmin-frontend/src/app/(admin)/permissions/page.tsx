"use client";

import React, { useState } from "react";
import PermissionMatrix from "../../../components/permissions/PermissionMatrix";
import RolePermissions from "../../../components/permissions/RolePermissions";
import UserModuleList from "../../../components/permissions/UserModuleList";
import { User } from "../../../services/types/user";
import RoleGuard from "../../../components/layout/RoleGuard";

type ViewMode = "matrix" | "roles" | "user-modules";

const PermissionsPage: React.FC = () => {
  return (
    <RoleGuard allowedRoles={['superadmin', 'admin']}>
      <PermissionsPageContent />
    </RoleGuard>
  );
};

const PermissionsPageContent: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>("matrix");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const handleUserSelect = (user: User) => {
    setSelectedUser(user);
    setViewMode("user-modules");
  };

  const handleBack = () => {
    setViewMode("matrix");
    setSelectedUser(null);
  };

  if (viewMode === "user-modules" && selectedUser) {
    return (
      <div className="p-6">
        <UserModuleList
          user={selectedUser}
          onBack={handleBack}
        />
      </div>
    );
  }

  if (viewMode === "roles") {
    return (
      <div className="p-6">
        <RolePermissions onBack={handleBack} />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Permissions Management
        </h1>
        <div className="flex space-x-4">
          <button
            onClick={() => setViewMode("matrix")}
            className={`px-4 py-2 rounded-lg font-medium ${
              viewMode === "matrix"
                ? "bg-blue-600 text-white"
                : "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300"
            }`}
          >
            Permission Matrix
          </button>
          <button
            onClick={() => setViewMode("roles")}
            className={`px-4 py-2 rounded-lg font-medium ${
              viewMode === "roles"
                ? "bg-blue-600 text-white"
                : "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300"
            }`}
          >
            Role Permissions
          </button>
        </div>
      </div>

      <PermissionMatrix
        onUserSelect={handleUserSelect}
        onModuleSelect={() => {}}
      />
    </div>
  );
};

export default PermissionsPage;