"use client";
import React, { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { RoleBasedContent } from "@/components/dashboard/RoleBasedContent";
import { dashboardService, DashboardMetrics, ActivityItem } from "@/services/api/dashboard";
import { userService } from "@/services/api/users";
import { moduleService } from "@/services/api/modules";
import { userTypeService } from "@/services/api/userTypes";

export default function DashboardClient() {
  const { user, isAuthenticated } = useAuth();
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalUsers: 0,
    activeUsers: 0,
    deletedUsers: 0,
    totalModules: 0,
    activeModules: 0,
    totalUserTypes: 0,
    usersUnderManagement: 0,
    assignedModules: 0,
    personalModules: 0,
  });
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    console.log('DashboardClient: useEffect triggered', { isAuthenticated, user });
    if (isAuthenticated && user) {
      console.log('DashboardClient: User authenticated, fetching data');
      fetchDashboardData();
    } else {
      console.log('DashboardClient: User not authenticated or no user data');
    }
  }, [isAuthenticated, user]);

  const fetchDashboardData = async () => {
    try {
      console.log('DashboardClient: Starting fetchDashboardData');
      setIsLoading(true);
      setError(null);

      const userRole = user?.userType?.name?.toLowerCase() || 'user';
      console.log('DashboardClient: User role determined as:', userRole);

      // Try to fetch from dashboard API first, fallback to individual API calls
      try {
        console.log('DashboardClient: Attempting to fetch from dashboard API');
        const [dashboardMetrics, dashboardActivities] = await Promise.all([
          dashboardService.getMetrics(userRole),
          dashboardService.getActivities({ userRole, limit: 10 }),
        ]);

        console.log('DashboardClient: Dashboard API success', { dashboardMetrics, dashboardActivities });
        setMetrics(dashboardMetrics);
        setActivities(dashboardActivities.activities);
      } catch (dashboardError) {
        // Fallback to individual API calls if dashboard endpoints don't exist yet
        console.warn('Dashboard API not available, falling back to individual calls:', dashboardError);
        console.log('DashboardClient: Starting fallback API calls');

        // Fetch data based on user role using existing APIs
        const promises = [];

        // Common data for all roles
        promises.push(userTypeService.getUserTypes());

        switch (userRole) {
          case 'superadmin':
            promises.push(
              userService.getAllUsers({ isDeleted: false }),
              userService.getAllUsers({ isDeleted: true }),
              moduleService.getModules({ isActive: true }),
              moduleService.getModules()
            );
            break;
          case 'admin':
            promises.push(
              userService.getUsers({ userTypeId: user?.userTypeId }),
              moduleService.getModules()
            );
            break;
          case 'manager':
            promises.push(
              userService.getUsers({ userTypeId: user?.userTypeId })
            );
            break;
          case 'user':
            // Users see limited data
            promises.push(
              moduleService.getModules({ isActive: true })
            );
            break;
        }

        const results = await Promise.all(promises);
        console.log('DashboardClient: Fallback API results:', results);

        // Process results based on role
        let newMetrics: DashboardMetrics = { ...metrics };

        switch (userRole) {
          case 'superadmin':
            const [userTypes, allUsers, deletedUsers, activeModules, allModules] = results;
            newMetrics = {
              ...newMetrics,
              totalUsers: allUsers.users.length,
              activeUsers: allUsers.users.filter(u => u.isActive).length,
              deletedUsers: deletedUsers.users.length,
              totalModules: allModules.modules.length,
              activeModules: activeModules.modules.length,
              totalUserTypes: userTypes.userTypes.length,
            };
            break;
          case 'admin':
            const [userTypesAdmin, managedUsers, allModulesAdmin] = results;
            newMetrics = {
              ...newMetrics,
              usersUnderManagement: managedUsers.users.length,
              activeUsers: managedUsers.users.filter(u => u.isActive).length,
              assignedModules: allModulesAdmin.modules.length,
              totalUserTypes: userTypesAdmin.userTypes.length,
            };
            break;
          case 'manager':
            const [userTypesManager, managedUsersManager] = results;
            newMetrics = {
              ...newMetrics,
              usersUnderManagement: managedUsersManager.users.length,
              activeUsers: managedUsersManager.users.filter(u => u.isActive).length,
              totalUserTypes: userTypesManager.userTypes.length,
            };
            break;
          case 'user':
            const [userTypesUser, userModules] = results;
            newMetrics = {
              ...newMetrics,
              personalModules: userModules.modules.length,
              totalUserTypes: userTypesUser.userTypes.length,
            };
            break;
        }

        console.log('DashboardClient: Setting new metrics:', newMetrics);
        setMetrics(newMetrics);

        // Mock activities data - in real app, this would come from an API
        const mockActivities = [
          {
            id: '1',
            type: 'user_created',
            description: 'New user registered in the system',
            timestamp: new Date().toISOString(),
            user: { firstName: 'John', lastName: 'Doe' },
          },
          {
            id: '2',
            type: 'login',
            description: `${user?.firstName} logged into the system`,
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            user: user ? { firstName: user.firstName, lastName: user.lastName } : undefined,
          },
        ];
        console.log('DashboardClient: Setting mock activities:', mockActivities);
        setActivities(mockActivities);
      }

    } catch (err: unknown) {
      const error = err as Error;
      setError(error.message || 'Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white/90 mb-2">
            Please sign in to access the dashboard
          </h2>
        </div>
      </div>
    );
  }

  return (
    <RoleBasedContent
      userRole={user?.userType?.name || 'user'}
      userData={user!}
      metrics={metrics}
      activities={activities}
      isLoading={isLoading}
      error={error}
    />
  );
}