"use client";

import React, { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import UserDetails from "../../../../components/users/UserDetails";
import { userService } from "../../../../services/api/users";
import { User } from "../../../../services/types/user";

const UserDetailsPage: React.FC = () => {
  const params = useParams();
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const userId = params.id as string;

  useEffect(() => {
    fetchUser();
  }, [userId, fetchUser]);

  const fetchUser = async () => {
    try {
      setLoading(true);
      const response = await userService.getUserById(userId);
      setUser(response.user);
    } catch (err) {
      setError("Failed to load user details");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    router.push(`/users/${userId}/edit`);
  };

  const handleBack = () => {
    router.push("/users");
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex justify-center items-center h-64">
          <div className="text-lg">Loading user details...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="p-6">
        <div className="text-center">User not found</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <UserDetails user={user} onEdit={handleEdit} onBack={handleBack} />
    </div>
  );
};

export default UserDetailsPage;