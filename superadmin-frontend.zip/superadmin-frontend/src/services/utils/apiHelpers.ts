import { AxiosResponse } from 'axios';
import { ApiResponse, ErrorResponse } from '../types/common';
import { ERROR_MESSAGES, HTTP_STATUS } from './constants';

export function handleApiResponse<T>(response: AxiosResponse): ApiResponse<T> {
  const { data, status } = response;

  if (status >= HTTP_STATUS.OK && status < HTTP_STATUS.BAD_REQUEST) {
    return {
      success: true,
      message: data.message || 'Success',
      data: data.data || data,
    };
  }

  return {
    success: false,
    message: data.message || 'An error occurred',
    error: data.error || 'Unknown error',
  };
}

export function handleApiError(error: any): ErrorResponse {
  if (error.response) {
    const { status, data } = error.response;

    switch (status) {
      case HTTP_STATUS.UNAUTHORIZED:
        return {
          success: false,
          message: ERROR_MESSAGES.UNAUTHORIZED,
          error: data.error || 'Unauthorized',
          statusCode: status,
        };
      case HTTP_STATUS.FORBIDDEN:
        return {
          success: false,
          message: ERROR_MESSAGES.FORBIDDEN,
          error: data.error || 'Forbidden',
          statusCode: status,
        };
      case HTTP_STATUS.NOT_FOUND:
        return {
          success: false,
          message: ERROR_MESSAGES.NOT_FOUND,
          error: data.error || 'Not found',
          statusCode: status,
        };
      case HTTP_STATUS.BAD_REQUEST:
      case HTTP_STATUS.UNPROCESSABLE_ENTITY:
        return {
          success: false,
          message: data.message || ERROR_MESSAGES.VALIDATION_ERROR,
          error: data.error || 'Validation error',
          statusCode: status,
        };
      case HTTP_STATUS.INTERNAL_SERVER_ERROR:
        return {
          success: false,
          message: ERROR_MESSAGES.SERVER_ERROR,
          error: data.error || 'Internal server error',
          statusCode: status,
        };
      default:
        return {
          success: false,
          message: data.message || ERROR_MESSAGES.UNKNOWN_ERROR,
          error: data.error || 'Unknown error',
          statusCode: status,
        };
    }
  }

  if (error.request) {
    return {
      success: false,
      message: ERROR_MESSAGES.NETWORK_ERROR,
      error: 'Network error',
      statusCode: 0,
    };
  }

  return {
    success: false,
    message: ERROR_MESSAGES.UNKNOWN_ERROR,
    error: error.message || 'Unknown error',
    statusCode: 0,
  };
}

export function createQueryString(params: Record<string, any>): string {
  const searchParams = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      searchParams.append(key, String(value));
    }
  });

  const queryString = searchParams.toString();
  return queryString ? `?${queryString}` : '';
}

export function formatApiUrl(endpoint: string, baseUrl: string = ''): string {
  if (endpoint.startsWith('http')) {
    return endpoint;
  }
  return `${baseUrl}${endpoint}`;
}