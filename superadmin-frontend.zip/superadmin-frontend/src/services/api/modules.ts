import apiClient from './client';
import { API_ENDPOINTS } from '../utils/constants';
import { createQueryString } from '../utils/apiHelpers';
import {
  Module,
  CreateModuleData,
  UpdateModuleData,
  ModuleListResponse,
  ModuleDetailResponse,
  ModuleFilters,
} from '../types/module';

export const moduleService = {
  // Get all modules (admin/manager access)
  async getModules(filters?: ModuleFilters): Promise<ModuleListResponse> {
    const queryString = createQueryString(filters || {});
    const response = await apiClient.get<ModuleListResponse>(
      `${API_ENDPOINTS.MODULES.LIST}${queryString}`
    );
    return response.data!;
  },

  // Get module by ID (admin/manager access)
  async getModuleById(id: string): Promise<ModuleDetailResponse> {
    const response = await apiClient.get<ModuleDetailResponse>(
      API_ENDPOINTS.MODULES.GET_BY_ID(id)
    );
    return response.data!;
  },

  // Create new module (admin access)
  async createModule(data: CreateModuleData): Promise<ModuleDetailResponse> {
    const response = await apiClient.post<ModuleDetailResponse>(
      API_ENDPOINTS.MODULES.CREATE,
      data
    );
    return response.data!;
  },

  // Update module (admin access)
  async updateModule(
    id: string,
    data: UpdateModuleData
  ): Promise<ModuleDetailResponse> {
    const response = await apiClient.put<ModuleDetailResponse>(
      API_ENDPOINTS.MODULES.UPDATE(id),
      data
    );
    return response.data!;
  },

  // Deactivate module (admin access)
  async deactivateModule(id: string): Promise<{ message: string }> {
    const response = await apiClient.patch<{ message: string }>(
      API_ENDPOINTS.MODULES.DEACTIVATE(id)
    );
    return response.data!;
  },
};