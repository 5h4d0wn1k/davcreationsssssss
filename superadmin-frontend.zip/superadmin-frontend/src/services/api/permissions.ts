import apiClient from './client';
import { API_ENDPOINTS } from '../utils/constants';
import {
  AssignModuleData,
  UnassignModuleData,
  BulkAssignModulesData,
  UserModulesResponse,
  PermissionResponse,
} from '../types/permission';

export const permissionService = {
  // Get user's modules (admin/manager access)
  async getUserModules(userId: string): Promise<UserModulesResponse> {
    const response = await apiClient.get<UserModulesResponse>(
      API_ENDPOINTS.PERMISSIONS.USER_MODULES(userId)
    );
    return response.data!;
  },

  // Assign module to user (admin access)
  async assignModule(data: AssignModuleData): Promise<PermissionResponse> {
    const response = await apiClient.post<PermissionResponse>(
      API_ENDPOINTS.PERMISSIONS.ASSIGN_MODULE,
      data
    );
    return response.data!;
  },

  // Unassign module from user (admin access)
  async unassignModule(data: UnassignModuleData): Promise<PermissionResponse> {
    const response = await apiClient.post<PermissionResponse>(
      API_ENDPOINTS.PERMISSIONS.UNASSIGN_MODULE,
      data
    );
    return response.data!;
  },

  // Bulk assign modules to user (admin access)
  async bulkAssignModules(data: BulkAssignModulesData): Promise<PermissionResponse> {
    const response = await apiClient.post<PermissionResponse>(
      API_ENDPOINTS.PERMISSIONS.BULK_ASSIGN_MODULES,
      data
    );
    return response.data!;
  },
};