import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { API_BASE_URL } from '../utils/constants';
import { handleApiError, handleApiResponse } from '../utils/apiHelpers';
import { ApiResponse } from '../types/common';

class ApiClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: true, // Enable cookies for session management
    });

    this.setupInterceptors();
  }

  private setupInterceptors(): void {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add any request preprocessing here
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response: AxiosResponse) => {
        return response;
      },
      (error) => {
        const handledError = handleApiError(error);
        return Promise.reject(handledError);
      }
    );
  }

  public async get<T = any>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      const response = await this.client.get(url, config);
      return handleApiResponse<T>(response);
    } catch (error) {
      throw error;
    }
  }

  public async post<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      console.log('Frontend: Making POST request to:', url, 'with data:', data);
      const response = await this.client.post(url, data, config);
      console.log('Frontend: POST response:', response);
      return handleApiResponse<T>(response);
    } catch (error) {
      console.log('Frontend: POST error:', error);
      throw error;
    }
  }

  public async put<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      const response = await this.client.put(url, data, config);
      return handleApiResponse<T>(response);
    } catch (error) {
      throw error;
    }
  }

  public async patch<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      const response = await this.client.patch(url, data, config);
      return handleApiResponse<T>(response);
    } catch (error) {
      throw error;
    }
  }

  public async delete<T = any>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      const response = await this.client.delete(url, config);
      return handleApiResponse<T>(response);
    } catch (error) {
      throw error;
    }
  }

  // Method to update base URL if needed
  public setBaseURL(baseURL: string): void {
    this.client.defaults.baseURL = baseURL;
  }

  // Method to add authorization header if needed
  public setAuthToken(token: string): void {
    this.client.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  }

  // Method to remove authorization header
  public removeAuthToken(): void {
    delete this.client.defaults.headers.common['Authorization'];
  }

  // Get the underlying axios instance for advanced usage
  public getInstance(): AxiosInstance {
    return this.client;
  }
}

// Create and export a singleton instance
const apiClient = new ApiClient();
export default apiClient;