"use client";

import React, { useState, useEffect } from "react";
import Input from "../form/input/InputField";
import Select from "../form/Select";
import Button from "../ui/button/Button";
import Label from "../form/Label";
import { User, CreateUserData, UpdateUserData } from "../../services/types/user";
import { userService } from "../../services/api/users";
import { userTypeService } from "../../services/api/userTypes";
import { UserType } from "../../services/types/userType";

interface UserFormProps {
  user?: User;
  onSuccess: () => void;
  onCancel: () => void;
}

const UserForm: React.FC<UserFormProps> = ({ user, onSuccess, onCancel }) => {
  const [formData, setFormData] = useState<CreateUserData | UpdateUserData>({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    address: "",
    userTypeId: "",
    bankName: "",
    bankIfscCode: "",
    bankAccountNumber: "",
    bankAddress: "",
    picture: "",
    ...(user && { isActive: user.isActive }),
  });

  const [userTypes, setUserTypes] = useState<UserType[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    fetchUserTypes();
    if (user) {
      setFormData({
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        email: user.email,
        address: user.address,
        userTypeId: user.userTypeId,
        bankName: user.bankName || "",
        bankIfscCode: user.bankIfscCode || "",
        bankAccountNumber: user.bankAccountNumber || "",
        bankAddress: user.bankAddress || "",
        picture: user.picture || "",
        isActive: user.isActive,
      });
    }
  }, [user]);

  const fetchUserTypes = async () => {
    try {
      const response = await userTypeService.getUserTypes();
      setUserTypes(response.userTypes || []);
    } catch (err) {
      console.error("Failed to load user types", err);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      if (user) {
        await userService.updateUser(user.id, formData as UpdateUserData);
        setSuccess("User updated successfully");
      } else {
        await userService.createUser(formData as CreateUserData);
        setSuccess("User created successfully");
      }
      setTimeout(() => onSuccess(), 1500); // Delay to show success message
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to save user");
    } finally {
      setLoading(false);
    }
  };

  const userTypeOptions = userTypes.map((type) => ({
    value: type.id,
    label: type.name,
  }));

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-6">
        {user ? "Edit User" : "Create New User"}
      </h2>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Personal Information */}
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Personal Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">First Name *</Label>
              <Input
                id="firstName"
                type="text"
                value={formData.firstName}
                onChange={(e) => handleInputChange("firstName", e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="lastName">Last Name *</Label>
              <Input
                id="lastName"
                type="text"
                value={formData.lastName}
                onChange={(e) => handleInputChange("lastName", e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone *</Label>
              <Input
                id="phone"
                type="text"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                required
              />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="address">Address *</Label>
              <Input
                id="address"
                type="text"
                value={formData.address}
                onChange={(e) => handleInputChange("address", e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="userTypeId">User Type *</Label>
              <Select
                options={userTypeOptions}
                placeholder="Select user type"
                onChange={(value) => handleInputChange("userTypeId", value)}
                defaultValue={formData.userTypeId}
              />
            </div>
            {!user && (
              <div>
                <Label htmlFor="password">Password *</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password || ""}
                    onChange={(e) => handleInputChange("password", e.target.value)}
                    required={!user}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                  >
                    {showPassword ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Banking Information */}
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Banking Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bankName">Bank Name</Label>
              <Input
                id="bankName"
                type="text"
                value={formData.bankName}
                onChange={(e) => handleInputChange("bankName", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="bankIfscCode">IFSC Code</Label>
              <Input
                id="bankIfscCode"
                type="text"
                value={formData.bankIfscCode}
                onChange={(e) => handleInputChange("bankIfscCode", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="bankAccountNumber">Account Number</Label>
              <Input
                id="bankAccountNumber"
                type="text"
                value={formData.bankAccountNumber}
                onChange={(e) => handleInputChange("bankAccountNumber", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="bankAddress">Bank Address</Label>
              <Input
                id="bankAddress"
                type="text"
                value={formData.bankAddress}
                onChange={(e) => handleInputChange("bankAddress", e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Profile Picture */}
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Profile Picture</h3>
          <div>
            <Label htmlFor="picture">Picture URL</Label>
            <Input
              id="picture"
              type="url"
              value={formData.picture}
              onChange={(e) => handleInputChange("picture", e.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          </div>
        </div>

        {/* Status (for edit only) */}
        {user && (
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-4">Status</h3>
            <div className="flex items-center">
              <input
                id="isActive"
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => handleInputChange("isActive", e.target.checked)}
                className="mr-2"
              />
              <Label htmlFor="isActive">Active</Label>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-4">
          <Button type="submit" disabled={loading}>
            {loading ? "Saving..." : user ? "Update User" : "Create User"}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
};

export default UserForm;