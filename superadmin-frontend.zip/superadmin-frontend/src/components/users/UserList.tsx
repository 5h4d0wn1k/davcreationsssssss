"use client";

import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import Badge from "../ui/badge/Badge";
import Button from "../ui/button/Button";
import Pagination from "../tables/Pagination";
import { userService } from "../../services/api/users";
import { User, UserFilters, UserListResponse } from "../../services/types/user";
import { useAuth } from "../../contexts/AuthContext";
import { TrashBinIcon as TrashIcon, UserIcon as UserXIcon } from "../../icons";
import UserActions from "./UserActions";
import UserFiltersComponent from "./UserFilters";

interface UserListProps {
  onViewUser: (user: User) => void;
  onEditUser: (user: User) => void;
  onCreateUser: () => void;
}

const UserList: React.FC<UserListProps> = ({
  onViewUser,
  onEditUser,
  onCreateUser,
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0,
  });
  const [filters, setFilters] = useState<UserFilters>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const fetchUsers = async (page = 1, currentFilters = filters) => {
    setLoading(true);
    setError(null);
    try {
      const response: UserListResponse = await userService.getUsers({
        ...currentFilters,
        page,
        limit: pagination.limit,
      });
      setUsers(response.users);
      setPagination(response.pagination);
    } catch (err) {
      setError("Failed to load users");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handlePageChange = (page: number) => {
    fetchUsers(page);
  };

  const handleFiltersChange = (newFilters: UserFilters) => {
    setFilters(newFilters);
    fetchUsers(1, newFilters);
  };

  const handleUserAction = async (action: string, userId: string) => {
    try {
      setError(null);
      setSuccess(null);

      switch (action) {
        case "delete":
          await userService.deleteUser(userId);
          setSuccess("User deleted successfully");
          fetchUsers();
          break;
        case "logout":
          await userService.logoutUser(userId);
          setSuccess("User logged out successfully");
          fetchUsers();
          break;
        case "recover":
          await userService.recoverUser(userId);
          setSuccess("User recovered successfully");
          fetchUsers();
          break;
        case "hardDelete":
          await userService.hardDeleteUser(userId);
          setSuccess("User permanently deleted");
          fetchUsers();
          break;
      }
    } catch (err: any) {
      setError(err.response?.data?.message || `Failed to ${action} user`);
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Users</h1>
        <Button onClick={onCreateUser}>Create User</Button>
      </div>

      <UserFiltersComponent onFiltersChange={handleFiltersChange} />

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
        <div className="max-w-full overflow-x-auto">
          <div className="min-w-[1200px]">
            <Table>
              <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    User
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Email
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Phone
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    User Type
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Status
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Actions
                  </TableCell>
                </TableRow>
              </TableHeader>

              <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : users.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      No users found
                    </TableCell>
                  </TableRow>
                ) : (
                  users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="px-5 py-4 sm:px-6 text-start">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 overflow-hidden rounded-full bg-gray-200">
                            {user.picture ? (
                              <img
                                src={user.picture}
                                alt={`${user.firstName} ${user.lastName}`}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-gray-500">
                                {user.firstName[0]}{user.lastName[0]}
                              </div>
                            )}
                          </div>
                          <div>
                            <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                              {user.firstName} {user.lastName}
                            </span>
                            <span className="block text-gray-500 text-theme-xs dark:text-gray-400">
                              {user.address}
                            </span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        {user.email}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        {user.phone}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        {user.userType?.name || "N/A"}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        <Badge
                          size="sm"
                          color={
                            user.isActive
                              ? "success"
                              : user.isDeleted
                              ? "error"
                              : "warning"
                          }
                        >
                          {user.isActive ? "Active" : user.isDeleted ? "Deleted" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        <UserActions
                          user={user}
                          onView={() => onViewUser(user)}
                          onEdit={() => onEditUser(user)}
                          onAction={handleUserAction}
                        />
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {pagination.totalPages > 1 && (
        <Pagination
          currentPage={pagination.page}
          totalPages={pagination.totalPages}
          onPageChange={handlePageChange}
        />
      )}
    </div>
  );
};

export default UserList;