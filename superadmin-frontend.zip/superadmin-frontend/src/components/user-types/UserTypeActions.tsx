"use client";

import React from "react";
import Button from "../ui/button/Button";
import { UserType } from "../../services/types/userType";
import { useAuth } from "../../contexts/AuthContext";
import { EyeIcon, PencilIcon, TrashBinIcon as TrashIcon } from "../../icons";

interface UserTypeActionsProps {
  userType: UserType;
  onView: () => void;
  onEdit: () => void;
  onAction: (action: string, userTypeId: string) => void;
}

const UserTypeActions: React.FC<UserTypeActionsProps> = ({
  userType,
  onView,
  onEdit,
  onAction,
}) => {
  const { user: currentUser } = useAuth();

  // Only superadmin can manage user types
  const isSuperAdmin = currentUser?.userType?.name === "superadmin";

  if (!isSuperAdmin) {
    return null;
  }

  // Prevent deletion of predefined roles
  const predefinedRoles = ["superadmin", "admin", "manager", "user"];
  const canDelete = !predefinedRoles.includes(userType.name.toLowerCase());

  return (
    <div className="flex items-center gap-2">
      <Button
        size="sm"
        variant="outline"
        onClick={onView}
        className="p-2"
      >
        <EyeIcon className="w-4 h-4" />
      </Button>

      <Button
        size="sm"
        variant="outline"
        onClick={onEdit}
        className="p-2"
      >
        <PencilIcon className="w-4 h-4" />
      </Button>

      {canDelete && (
        <Button
          size="sm"
          variant="outline"
          onClick={() => onAction("delete", userType.id)}
          className="p-2 text-red-600 hover:text-red-700"
        >
          <TrashIcon className="w-4 h-4" />
        </Button>
      )}
    </div>
  );
};

export default UserTypeActions;