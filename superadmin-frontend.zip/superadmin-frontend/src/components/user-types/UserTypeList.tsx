"use client";

import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import Badge from "../ui/badge/Badge";
import Button from "../ui/button/Button";
import Pagination from "../tables/Pagination";
import { userTypeService } from "../../services/api/userTypes";
import { UserType, UserTypeListResponse } from "../../services/types/userType";
import { useAuth } from "../../contexts/AuthContext";
import UserTypeActions from "./UserTypeActions";

interface UserTypeListProps {
  onViewUserType: (userType: UserType) => void;
  onEditUserType: (userType: UserType) => void;
  onCreateUserType: () => void;
}

const UserTypeList: React.FC<UserTypeListProps> = ({
  onViewUserType,
  onEditUserType,
  onCreateUserType,
}) => {
  const [userTypes, setUserTypes] = useState<UserType[]>([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const { user: currentUser } = useAuth();

  // Role hierarchy for display
  const roleHierarchy = {
    superadmin: 4,
    admin: 3,
    manager: 2,
    user: 1,
  };

  const fetchUserTypes = async () => {
    setLoading(true);
    setError(null);
    try {
      const response: UserTypeListResponse = await userTypeService.getUserTypes();
      setUserTypes(response.userTypes || []);
      // For now, we'll handle pagination on the frontend
      setPagination({
        page: 1,
        limit: 10,
        total: response.userTypes?.length || 0,
        totalPages: Math.ceil((response.userTypes?.length || 0) / 10),
      });
    } catch (err) {
      setError("Failed to load user types");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserTypes();
  }, []);

  const handleUserTypeAction = async (action: string, userTypeId: string) => {
    try {
      setError(null);
      setSuccess(null);

      if (action === "delete") {
        await userTypeService.deleteUserType(userTypeId);
        setSuccess("User type deleted successfully");
        fetchUserTypes();
      }
    } catch (err: any) {
      setError(err.response?.data?.message || `Failed to ${action} user type`);
      console.error(err);
    }
  };

  // Check if current user is superadmin
  const isSuperAdmin = currentUser?.userType?.name === "superadmin";

  if (!isSuperAdmin) {
    return (
      <div className="p-6">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          Access denied. Only superadmin can manage user types.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">User Types</h1>
          <p className="text-gray-600 mt-1">
            Role Hierarchy: Superadmin → Admin → Manager → User
          </p>
        </div>
        <Button onClick={onCreateUserType}>Create User Type</Button>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
        <div className="max-w-full overflow-x-auto">
          <div className="min-w-[800px]">
            <Table>
              <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Name
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Hierarchy Level
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Status
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Created
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Actions
                  </TableCell>
                </TableRow>
              </TableHeader>

              <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : userTypes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      No user types found
                    </TableCell>
                  </TableRow>
                ) : (
                  userTypes
                    .sort((a, b) => (roleHierarchy[b.name.toLowerCase() as keyof typeof roleHierarchy] || 0) - (roleHierarchy[a.name.toLowerCase() as keyof typeof roleHierarchy] || 0))
                    .map((userType) => (
                      <TableRow key={userType.id}>
                        <TableCell className="px-5 py-4 text-start">
                          <span className="font-medium text-gray-800 text-theme-sm dark:text-white/90">
                            {userType.name}
                          </span>
                        </TableCell>
                        <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                          {roleHierarchy[userType.name.toLowerCase() as keyof typeof roleHierarchy] || "N/A"}
                        </TableCell>
                        <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                          <Badge
                            size="sm"
                            color={userType.isActive ? "success" : "error"}
                          >
                            {userType.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                          {new Date(userType.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                          <UserTypeActions
                            userType={userType}
                            onView={() => onViewUserType(userType)}
                            onEdit={() => onEditUserType(userType)}
                            onAction={handleUserTypeAction}
                          />
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {pagination.totalPages > 1 && (
        <Pagination
          currentPage={pagination.page}
          totalPages={pagination.totalPages}
          onPageChange={() => {}} // For now, no pagination on backend
        />
      )}
    </div>
  );
};

export default UserTypeList;