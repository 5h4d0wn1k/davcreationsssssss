"use client";

import React, { useState, useEffect } from "react";
import Button from "../ui/button/Button";
import MultiSelect from "../form/MultiSelect";
import { userService } from "../../services/api/users";
import { moduleService } from "../../services/api/modules";
import { permissionService } from "../../services/api/permissions";
import { User } from "../../services/types/user";
import { Module } from "../../services/types/module";

const BulkAssignForm: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [modules, setModules] = useState<Module[]>([]);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [selectedModuleIds, setSelectedModuleIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const fetchData = async () => {
    setFetchingData(true);
    setError(null);
    try {
      const [usersResponse, modulesResponse] = await Promise.all([
        userService.getUsers({ limit: 1000 }), // Get all users
        moduleService.getModules({ limit: 1000 }), // Get all modules
      ]);

      setUsers(usersResponse.users);
      setModules(modulesResponse.modules);
    } catch (err) {
      setError("Failed to load users and modules");
      console.error(err);
    } finally {
      setFetchingData(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (selectedUserIds.length === 0 || selectedModuleIds.length === 0) {
      setError("Please select at least one user and one module");
      return;
    }

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      // Process bulk assignment for each user
      const promises = selectedUserIds.map(userId =>
        permissionService.bulkAssignModules({
          userId,
          moduleIds: selectedModuleIds,
        })
      );

      await Promise.all(promises);

      setSuccess(`Successfully assigned ${selectedModuleIds.length} modules to ${selectedUserIds.length} users`);
      setSelectedUserIds([]);
      setSelectedModuleIds([]);
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to bulk assign permissions");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const userOptions = users.map(user => ({
    value: user.id,
    text: `${user.firstName} ${user.lastName} (${user.email})`,
    selected: selectedUserIds.includes(user.id),
  }));

  const moduleOptions = modules.map(module => ({
    value: module.id,
    text: `${module.name}${module.toolTip ? ` - ${module.toolTip}` : ''}`,
    selected: selectedModuleIds.includes(module.id),
  }));

  if (fetchingData) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="text-gray-500">Loading form data...</div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        )}

        {success && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
            {success}
          </div>
        )}

        <div>
          <MultiSelect
            label="Select Users"
            options={userOptions}
            defaultSelected={selectedUserIds}
            onChange={setSelectedUserIds}
          />
          <p className="text-sm text-gray-500 mt-1">
            Selected {selectedUserIds.length} user{selectedUserIds.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div>
          <MultiSelect
            label="Select Modules to Assign"
            options={moduleOptions}
            defaultSelected={selectedModuleIds}
            onChange={setSelectedModuleIds}
          />
          <p className="text-sm text-gray-500 mt-1">
            Selected {selectedModuleIds.length} module{selectedModuleIds.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
          <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2">
            Bulk Assignment Summary
          </h3>
          <p className="text-sm text-blue-700 dark:text-blue-300">
            This will assign {selectedModuleIds.length} module{selectedModuleIds.length !== 1 ? 's' : ''} to {selectedUserIds.length} user{selectedUserIds.length !== 1 ? 's' : ''}.
            Existing permissions will not be affected - only new assignments will be made.
          </p>
        </div>

        <div className="flex justify-end space-x-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setSelectedUserIds([]);
              setSelectedModuleIds([]);
              setError(null);
              setSuccess(null);
            }}
          >
            Clear Selection
          </Button>
          <Button
            type="submit"
            disabled={loading || selectedUserIds.length === 0 || selectedModuleIds.length === 0}
          >
            {loading ? "Assigning..." : "Bulk Assign Permissions"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default BulkAssignForm;