"use client";

import React, { useState, useEffect } from "react";
import Input from "../form/input/InputField";
import Select from "../form/Select";
import Button from "../ui/button/Button";
import Label from "../form/Label";
import TextArea from "../form/input/TextArea";
import { Module, CreateModuleData, UpdateModuleData } from "../../services/types/module";
import { moduleService } from "../../services/api/modules";
import { ModuleListResponse } from "../../services/types/module";

interface ModuleFormProps {
  module?: Module;
  onSuccess: () => void;
  onCancel: () => void;
}

const ModuleForm: React.FC<ModuleFormProps> = ({ module, onSuccess, onCancel }) => {
  const [formData, setFormData] = useState<CreateModuleData | UpdateModuleData>({
    name: "",
    parentId: "",
    toolTip: "",
    description: "",
    urlSlug: "",
    ...(module && { isActive: module.isActive }),
  });

  const [modules, setModules] = useState<Module[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    fetchModules();
    if (module) {
      setFormData({
        name: module.name,
        parentId: module.parentId || "",
        toolTip: module.toolTip || "",
        description: module.description || "",
        urlSlug: module.urlSlug,
        isActive: module.isActive,
      });
    }
  }, [module]);

  const fetchModules = async () => {
    try {
      const response: ModuleListResponse = await moduleService.getModules();
      setModules(response.modules || []);
    } catch (err) {
      console.error("Failed to load modules", err);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      if (module) {
        await moduleService.updateModule(module.id, formData as UpdateModuleData);
        setSuccess("Module updated successfully");
      } else {
        await moduleService.createModule(formData as CreateModuleData);
        setSuccess("Module created successfully");
      }
      setTimeout(() => onSuccess(), 1500); // Delay to show success message
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to save module");
    } finally {
      setLoading(false);
    }
  };

  const parentModuleOptions = [
    { value: "", label: "Root Module" },
    ...modules
      .filter((m) => m.id !== module?.id) // Exclude current module to prevent self-reference
      .map((m) => ({
        value: m.id,
        label: m.name,
      })),
  ];

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-6">
        {module ? "Edit Module" : "Create New Module"}
      </h2>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Basic Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="name">Module Name *</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="urlSlug">URL Slug *</Label>
              <Input
                id="urlSlug"
                type="text"
                value={formData.urlSlug}
                onChange={(e) => handleInputChange("urlSlug", e.target.value)}
                required
                placeholder="e.g., user-management"
              />
            </div>
            <div>
              <Label htmlFor="parentId">Parent Module</Label>
              <Select
                options={parentModuleOptions}
                placeholder="Select parent module"
                onChange={(value) => handleInputChange("parentId", value)}
                defaultValue={formData.parentId}
              />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="toolTip">Tool Tip</Label>
              <Input
                id="toolTip"
                type="text"
                value={formData.toolTip}
                onChange={(e) => handleInputChange("toolTip", e.target.value)}
                placeholder="Brief tooltip text"
              />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <TextArea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Detailed description of the module"
                rows={3}
              />
            </div>
          </div>
        </div>

        {/* Status (for edit only) */}
        {module && (
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-4">Status</h3>
            <div className="flex items-center">
              <input
                id="isActive"
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => handleInputChange("isActive", e.target.checked)}
                className="mr-2"
              />
              <Label htmlFor="isActive">Active</Label>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-4">
          <Button type="submit" disabled={loading}>
            {loading ? "Saving..." : module ? "Update Module" : "Create Module"}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ModuleForm;