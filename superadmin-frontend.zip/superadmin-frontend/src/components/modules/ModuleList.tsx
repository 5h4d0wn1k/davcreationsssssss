"use client";

import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import Badge from "../ui/badge/Badge";
import Button from "../ui/button/Button";
import Pagination from "../tables/Pagination";
import { moduleService } from "../../services/api/modules";
import { Module, ModuleFilters, ModuleListResponse } from "../../services/types/module";
import { useAuth } from "../../contexts/AuthContext";
import { TrashBinIcon as TrashIcon } from "../../icons";
import ModuleActions from "./ModuleActions";
import ModuleFiltersComponent from "./ModuleFilters";

interface ModuleListProps {
  onViewModule: (module: Module) => void;
  onEditModule: (module: Module) => void;
  onCreateModule: () => void;
}

const ModuleList: React.FC<ModuleListProps> = ({
  onViewModule,
  onEditModule,
  onCreateModule,
}) => {
  const [modules, setModules] = useState<Module[]>([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0,
  });
  const [filters, setFilters] = useState<ModuleFilters>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const fetchModules = async (page = 1, currentFilters = filters) => {
    setLoading(true);
    setError(null);
    try {
      const response: ModuleListResponse = await moduleService.getModules({
        ...currentFilters,
        page,
        limit: pagination.limit,
      });
      setModules(response.modules);
      setPagination(response.pagination);
    } catch (err) {
      setError("Failed to load modules");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModules();
  }, []);

  const handlePageChange = (page: number) => {
    fetchModules(page);
  };

  const handleFiltersChange = (newFilters: ModuleFilters) => {
    setFilters(newFilters);
    fetchModules(1, newFilters);
  };

  const handleModuleAction = async (action: string, moduleId: string) => {
    try {
      setError(null);
      setSuccess(null);

      switch (action) {
        case "deactivate":
          await moduleService.deactivateModule(moduleId);
          setSuccess("Module deactivated successfully");
          fetchModules();
          break;
      }
    } catch (err: any) {
      setError(err.response?.data?.message || `Failed to ${action} module`);
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Modules</h1>
        <Button onClick={onCreateModule}>Create Module</Button>
      </div>

      <ModuleFiltersComponent onFiltersChange={handleFiltersChange} />

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}

      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
        <div className="max-w-full overflow-x-auto">
          <div className="min-w-[1200px]">
            <Table>
              <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Module Name
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    URL Slug
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Parent Module
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Description
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Status
                  </TableCell>
                  <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                    Actions
                  </TableCell>
                </TableRow>
              </TableHeader>

              <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : modules.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      No modules found
                    </TableCell>
                  </TableRow>
                ) : (
                  modules.map((module) => (
                    <TableRow key={module.id}>
                      <TableCell className="px-5 py-4 sm:px-6 text-start">
                        <div>
                          <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                            {module.name}
                          </span>
                          {module.toolTip && (
                            <span className="block text-gray-500 text-theme-xs dark:text-gray-400">
                              {module.toolTip}
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        {module.urlSlug}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        {module.parent?.name || "Root"}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        {module.description || "N/A"}
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        <Badge
                          size="sm"
                          color={module.isActive ? "success" : "error"}
                        >
                          {module.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                        <ModuleActions
                          module={module}
                          onView={() => onViewModule(module)}
                          onEdit={() => onEditModule(module)}
                          onAction={handleModuleAction}
                        />
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {pagination.totalPages > 1 && (
        <Pagination
          currentPage={pagination.page}
          totalPages={pagination.totalPages}
          onPageChange={handlePageChange}
        />
      )}
    </div>
  );
};

export default ModuleList;