"use client";

import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { User, Session, LoginCredentials, RegisterData, GoogleLoginData, ForgotPasswordData, SendOtpData, VerifyOtpData } from '../services/types/auth';
import { authService } from '../services/api/auth';

interface AuthState {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: string | null;
}

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  logoutAll: () => Promise<void>;
  googleLogin: (data: GoogleLoginData) => Promise<void>;
  forgotPassword: (data: ForgotPasswordData) => Promise<void>;
  sendOtp: (data: SendOtpData) => Promise<void>;
  verifyOtp: (data: VerifyOtpData) => Promise<void>;
  refreshSession: () => Promise<void>;
  clearError: () => void;
}

type AuthAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_SESSION'; payload: Session | null }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'LOGOUT' };

const initialState: AuthState = {
  user: null,
  session: null,
  isLoading: true,
  isAuthenticated: false,
  error: null,
};

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_USER':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: !!action.payload,
        error: null,
      };
    case 'SET_SESSION':
      return { ...state, session: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'LOGOUT':
      return {
        ...initialState,
        isLoading: false,
      };
    default:
      return state;
  }
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Check for existing session on mount
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const user = await authService.getCurrentUser();
        dispatch({ type: 'SET_USER', payload: user });
        // Note: Session info might need to be stored separately or retrieved
      } catch (error) {
        // User not authenticated
      } finally {
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };

    checkAuthStatus();
  }, []);

  // Auto refresh session before expiry
  useEffect(() => {
    if (state.session?.expiry) {
      const expiryTime = state.session.expiry * 1000; // Convert to milliseconds
      const currentTime = Date.now();
      const timeUntilExpiry = expiryTime - currentTime;

      // Refresh 5 minutes before expiry
      const refreshTime = timeUntilExpiry - 5 * 60 * 1000;

      if (refreshTime > 0) {
        const timer = setTimeout(() => {
          refreshSession();
        }, refreshTime);

        return () => clearTimeout(timer);
      } else if (timeUntilExpiry <= 0) {
        // Session already expired
        logout();
      }
    }
  }, [state.session]);

  const login = async (credentials: LoginCredentials) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const response = await authService.login(credentials);
      dispatch({ type: 'SET_USER', payload: response.user });
      dispatch({ type: 'SET_SESSION', payload: response.session });
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message || 'Login failed' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const register = async (data: RegisterData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const response = await authService.register(data);
      dispatch({ type: 'SET_USER', payload: response.user });
      dispatch({ type: 'SET_SESSION', payload: response.session });
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message || 'Registration failed' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const logout = async () => {
    try {
      await authService.logout();
    } catch (error) {
      // Continue with logout even if API call fails
    } finally {
      dispatch({ type: 'LOGOUT' });
    }
  };

  const logoutAll = async () => {
    try {
      await authService.logoutAll();
    } catch (error) {
      // Continue with logout even if API call fails
    } finally {
      dispatch({ type: 'LOGOUT' });
    }
  };

  const googleLogin = async (data: GoogleLoginData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const response = await authService.googleLogin(data);
      dispatch({ type: 'SET_USER', payload: response.user });
      dispatch({ type: 'SET_SESSION', payload: response.session });
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message || 'Google login failed' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const forgotPassword = async (data: ForgotPasswordData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      await authService.forgotPassword(data);
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message || 'Forgot password failed' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const sendOtp = async (data: SendOtpData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      await authService.sendOtp(data);
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message || 'Send OTP failed' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const verifyOtp = async (data: VerifyOtpData) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      await authService.verifyOtp(data);
    } catch (error: any) {
      dispatch({ type: 'SET_ERROR', payload: error.message || 'Verify OTP failed' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const refreshSession = async () => {
    try {
      const user = await authService.getCurrentUser();
      dispatch({ type: 'SET_USER', payload: user });
      // Note: May need to get updated session info
    } catch (error) {
      logout();
    }
  };

  const clearError = () => {
    dispatch({ type: 'SET_ERROR', payload: null });
  };

  const value: AuthContextType = {
    ...state,
    login,
    register,
    logout,
    logoutAll,
    googleLogin,
    forgotPassword,
    sendOtp,
    verifyOtp,
    refreshSession,
    clearError,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};